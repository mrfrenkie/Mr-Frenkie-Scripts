---@diagnostic disable: undefined-global, undefined-field
local r = reaper
local Utils = require("Utils")

local Track = {}

function Track.GetSelectedTracks()
    local count = r.CountSelectedTracks(0)
    if count == 0 then
        return {}
    end
    local tracks = {}
    for i = 0, count - 1 do
        local track = r.GetSelectedTrack(0, i)
        if track and r.ValidatePtr(track, "MediaTrack*") then
            tracks[#tracks + 1] = track
        end
    end
    return tracks
end

function Track.FreezeTracks(tracks)
    r.Main_OnCommand(41223, 0)
end

function Track.UnfreezeTracks(tracks)
    r.Main_OnCommand(41644, 0)
end

function Track.GetFreezeCountForTrack(track)
    if not track or not r.ValidatePtr(track, 'MediaTrack*') then return 0 end
    local val = r.GetMediaTrackInfo_Value(track, 'I_FREEZECOUNT') or 0
    return math.floor(val)
end

function Track.GetFreezeStats(tracks)
    local total = 0
    local track_count = 0
    local frozen_count = 0
    if tracks then
        for _, tr in ipairs(tracks) do
            local cnt = Track.GetFreezeCountForTrack(tr)
            total = total + cnt
            track_count = track_count + 1
            if cnt > 0 then frozen_count = frozen_count + 1 end
        end
    end
    local has = (frozen_count > 0)
    local all_frozen = (track_count > 0 and frozen_count == track_count)
    local none_frozen = (frozen_count == 0)
    local mixed = (frozen_count > 0 and frozen_count < track_count)
    return {
        total = total,
        has = has,
        track_count = track_count,
        frozen_count = frozen_count,
        all_frozen = all_frozen,
        none_frozen = none_frozen,
        mixed = mixed,
    }
end

function Track.GetTotalFXLatency(track)
    if not track or not r.ValidatePtr(track, 'MediaTrack*') then return nil end
    local total = 0
    local has_latency = (r.TrackFX_GetLatency ~= nil)
    local has_named = (r.TrackFX_GetNamedConfigParm ~= nil)
    local fx_count = r.TrackFX_GetCount(track) or 0
    for i = 0, fx_count - 1 do
        local enabled = r.TrackFX_GetEnabled(track, i)
        local offline = r.TrackFX_GetOffline(track, i)
        if enabled and not offline then
            local lat = 0
            if has_latency then
                lat = r.TrackFX_GetLatency(track, i) or 0
            elseif has_named then
                local ok, val = r.TrackFX_GetNamedConfigParm(track, i, 'pdc')
                if ok and val then
                    local tmp = tonumber(val)
                    if tmp ~= nil then lat = tmp end
                else
                    local ok2, val2 = r.TrackFX_GetNamedConfigParm(track, i, 'latency')
                    if ok2 and val2 then
                        local tmp2 = tonumber(val2)
                        if tmp2 ~= nil then lat = tmp2 end
                    end
                end
            end
            total = total + lat
        end
    end
    local rec_count = 0
    local ok = pcall(function() rec_count = r.TrackFX_GetRecCount(track) or 0 end)
    if ok and rec_count > 0 then
        for i = 0, rec_count - 1 do
            local idx = 0x1000000 + i
            local enabled = r.TrackFX_GetEnabled(track, idx)
            local offline = r.TrackFX_GetOffline(track, idx)
            if enabled and not offline then
                local lat = 0
                if has_latency then
                    lat = r.TrackFX_GetLatency(track, idx) or 0
                elseif has_named then
                    local ok3, val3 = r.TrackFX_GetNamedConfigParm(track, idx, 'pdc')
                    if ok3 and val3 then
                        local tmp3 = tonumber(val3)
                        if tmp3 ~= nil then lat = tmp3 end
                    else
                        local ok4, val4 = r.TrackFX_GetNamedConfigParm(track, idx, 'latency')
                        if ok4 and val4 then
                            local tmp4 = tonumber(val4)
                            if tmp4 ~= nil then lat = tmp4 end
                        end
                    end
                end
                total = total + lat
            end
        end
    end
    if total == 0 and not has_latency and not has_named then return nil end
    return total
end

function Track.GetPerfInfo(track)
    return {
        pdc_spl = Track.GetTotalFXLatency(track)
    }
end

local HP_FX_NAME = "JS: Mr. Frenkie/Low Cut 24 dB/oct"
local LP_FX_NAME = "JS: Mr. Frenkie/High Cut 24 dB/oct"

local function ensure_mt_front(track)
    if not track or not r.ValidatePtr(track, "MediaTrack*") then return nil end
    Utils.EnsureMIDITransposeUtilityInstalled()
    local existing = r.TrackFX_GetByName(track, "JS: Mr. Frenkie/MIDI Transpose Utility", false)
    if existing == -1 then
        existing = r.TrackFX_GetByName(track, "JS: MIDI Transpose Utility", false)
    end
    if existing ~= -1 then
        pcall(r.TrackFX_Delete, track, existing)
    end
    local add_idx = r.TrackFX_AddByName(track, "JS: Mr. Frenkie/MIDI Transpose Utility", false, 1)
    if add_idx == -1 then
        add_idx = r.TrackFX_AddByName(track, "JS: MIDI Transpose Utility", false, 1)
    end
    if add_idx == -1 then return nil end
    r.TrackFX_CopyToTrack(track, add_idx, track, 0, true)
    local fx_idx = 0
    Utils.ApplyMIDITransposePreset(track, fx_idx)
    Utils.EnableEmbeddedUIMCP(track, fx_idx)
    pcall(r.TrackFX_SetOpen, track, fx_idx, false)
    return fx_idx
end

local function find_fx_by_name(track, name)
    if not track or not r.ValidatePtr(track, "MediaTrack*") then return nil end
    local fx_cnt = r.TrackFX_GetCount(track) or 0
    for i = 0, fx_cnt - 1 do
        local ok, fx_name = r.TrackFX_GetFXName(track, i, "")
        if ok and fx_name and fx_name:find(name, 1, true) then
            return i
        end
    end
    return nil
end

-- norm_when_create, slope_when_create: used only when adding NEW FX (no existing). When re-adding we read from existing.
local function ensure_hp_only_at_end(track, norm_when_create, slope_when_create)
    if not track or not r.ValidatePtr(track, "MediaTrack*") then return nil end
    Utils.EnsureFilterEffectsInstalled()
    local hp_idx = find_fx_by_name(track, "Low Cut 24")
    local norm, slope = norm_when_create, slope_when_create
    if norm == nil then norm = 0.2 end
    if slope == nil then slope = 1 end
    norm = math.max(0, math.min(1, norm))
    slope = slope and 1 or 0
    if hp_idx ~= nil then
        local fx_count = r.TrackFX_GetCount(track) or 0
        if hp_idx == fx_count - 1 then
            Utils.EnableEmbeddedUIForFX(track, hp_idx)
            return hp_idx
        end
        norm = r.TrackFX_GetParam(track, hp_idx, 0) or 0.2
        slope = r.TrackFX_GetParam(track, hp_idx, 1) or 1
        pcall(r.TrackFX_Delete, track, hp_idx)
    end
    local add_hp = r.TrackFX_AddByName(track, HP_FX_NAME, false, -1)
    if add_hp == -1 then return nil end
    r.TrackFX_SetParam(track, add_hp, 0, norm)
    r.TrackFX_SetParam(track, add_hp, 1, slope)
    Utils.EnableEmbeddedUIForFX(track, add_hp)
    pcall(r.TrackFX_SetOpen, track, add_hp, false)
    r.TrackFX_SetParam(track, add_hp, 0, norm)
    return add_hp
end

local function ensure_lp_only_at_end(track, norm_when_create, slope_when_create)
    if not track or not r.ValidatePtr(track, "MediaTrack*") then return nil end
    Utils.EnsureFilterEffectsInstalled()
    local lp_idx = find_fx_by_name(track, "High Cut 24")
    local norm, slope = norm_when_create, slope_when_create
    if norm == nil then norm = 0.8 end
    if slope == nil then slope = 1 end
    norm = math.max(0, math.min(1, norm))
    slope = slope and 1 or 0
    if lp_idx ~= nil then
        local fx_count = r.TrackFX_GetCount(track) or 0
        if lp_idx == fx_count - 1 then
            Utils.EnableEmbeddedUIForFX(track, lp_idx)
            return lp_idx
        end
        norm = r.TrackFX_GetParam(track, lp_idx, 0) or 0.8
        slope = r.TrackFX_GetParam(track, lp_idx, 1) or 1
        pcall(r.TrackFX_Delete, track, lp_idx)
    end
    local add_lp = r.TrackFX_AddByName(track, LP_FX_NAME, false, -1)
    if add_lp == -1 then return nil end
    r.TrackFX_SetParam(track, add_lp, 0, norm)
    r.TrackFX_SetParam(track, add_lp, 1, slope)
    Utils.EnableEmbeddedUIForFX(track, add_lp)
    pcall(r.TrackFX_SetOpen, track, add_lp, false)
    r.TrackFX_SetParam(track, add_lp, 0, norm)
    return add_lp
end

local function ensure_filters_at_end(track)
    if not track or not r.ValidatePtr(track, "MediaTrack*") then return end
    Utils.EnsureFilterEffectsInstalled()
    local fx_count = r.TrackFX_GetCount(track) or 0
    local hp_idx = find_fx_by_name(track, "Low Cut 24")
    local lp_idx = find_fx_by_name(track, "High Cut 24")
    local hp_last = (hp_idx ~= nil and hp_idx == fx_count - 2)
    local lp_last = (lp_idx ~= nil and lp_idx == fx_count - 1)
    if hp_last and lp_last then
        Utils.EnableEmbeddedUIForFX(track, hp_idx)
        Utils.EnableEmbeddedUIForFX(track, lp_idx)
        return
    end
    local hp_norm, hp_slope = 0.2, 1
    local lp_norm, lp_slope = 0.8, 1
    if hp_idx ~= nil then
        local v = r.TrackFX_GetParam(track, hp_idx, 0)
        if v ~= nil then hp_norm = v end
        local s = r.TrackFX_GetParam(track, hp_idx, 1)
        if s ~= nil then hp_slope = s end
        pcall(r.TrackFX_Delete, track, hp_idx)
        fx_count = fx_count - 1
        if lp_idx ~= nil and lp_idx > hp_idx then lp_idx = lp_idx - 1 end
    end
    if lp_idx ~= nil then
        local v = r.TrackFX_GetParam(track, lp_idx, 0)
        if v ~= nil then lp_norm = v end
        local s = r.TrackFX_GetParam(track, lp_idx, 1)
        if s ~= nil then lp_slope = s end
        pcall(r.TrackFX_Delete, track, lp_idx)
        fx_count = fx_count - 1
    end
    local add_hp = r.TrackFX_AddByName(track, HP_FX_NAME, false, -1)
    if add_hp == -1 then return end
    r.TrackFX_SetParam(track, add_hp, 0, hp_norm)
    r.TrackFX_SetParam(track, add_hp, 1, hp_slope)
    Utils.EnableEmbeddedUIForFX(track, add_hp)
    local add_lp = r.TrackFX_AddByName(track, LP_FX_NAME, false, -1)
    if add_lp == -1 then return end
    r.TrackFX_SetParam(track, add_lp, 0, lp_norm)
    r.TrackFX_SetParam(track, add_lp, 1, lp_slope)
    Utils.EnableEmbeddedUIForFX(track, add_lp)
    pcall(r.TrackFX_SetOpen, track, add_hp, false)
    pcall(r.TrackFX_SetOpen, track, add_lp, false)
end

local function find_transpose_param(track, fx_idx)
    if not track or not r.ValidatePtr(track, "MediaTrack*") then return nil end
    if fx_idx == nil or fx_idx < 0 then return nil end
    local param_count = r.TrackFX_GetNumParams(track, fx_idx) or 0
    for p = 0, param_count - 1 do
        local ok, name = r.TrackFX_GetParamName(track, fx_idx, p, "")
        if ok and name then
            local n = name:lower()
            if n:find("transpose") or n:find("semitone") or n:find("semitones") or n:find("shift") then
                return p
            end
        end
    end
    if param_count > 0 then return 0 end
    return nil
end

function Track.FindMidiTransposeFX(track)
    if not track or not r.ValidatePtr(track, "MediaTrack*") then return nil end
    local fx_cnt = r.TrackFX_GetCount(track) or 0
    for i = 0, fx_cnt - 1 do
        local ok, name = r.TrackFX_GetFXName(track, i, "")
        if ok and name and name:lower():find("midi transpose utility") then
            return i
        end
    end
    return nil
end

function Track.FindHPFilterFX(track)
    return find_fx_by_name(track, "Low Cut 24")
end

function Track.FindLPFilterFX(track)
    return find_fx_by_name(track, "High Cut 24")
end

function Track.EnsureFiltersAtEnd(track)
    ensure_filters_at_end(track)
end

function Track.EnsureHPFilterOnly(track, norm_when_create, slope_when_create)
    return ensure_hp_only_at_end(track, norm_when_create, slope_when_create)
end

function Track.EnsureLPFilterOnly(track, norm_when_create, slope_when_create)
    return ensure_lp_only_at_end(track, norm_when_create, slope_when_create)
end

function Track.RemoveHPFilterFX(track)
    if not track or not r.ValidatePtr(track, "MediaTrack*") then return end
    local idx = find_fx_by_name(track, "Low Cut 24")
    if idx ~= nil then
        pcall(r.TrackFX_Delete, track, idx)
    end
end

function Track.RemoveLPFilterFX(track)
    if not track or not r.ValidatePtr(track, "MediaTrack*") then return end
    local idx = find_fx_by_name(track, "High Cut 24")
    if idx ~= nil then
        pcall(r.TrackFX_Delete, track, idx)
    end
end

function Track.GetFilterFreqNorm(track, fx_idx)
    if not track or fx_idx == nil or fx_idx < 0 then return nil end
    return r.TrackFX_GetParam(track, fx_idx, 0)
end

function Track.SetFilterFreqNorm(track, fx_idx, norm)
    if not track or fx_idx == nil or fx_idx < 0 then return end
    norm = math.max(0, math.min(1, norm))
    r.TrackFX_SetParam(track, fx_idx, 0, norm)
end

function Track.GetFilterSlope24(track, fx_idx)
    if not track or fx_idx == nil or fx_idx < 0 then return nil end
    local v = r.TrackFX_GetParam(track, fx_idx, 1)
    return v ~= nil and v >= 0.5
end

-- Change slope (param 1) only; preserve frequency (param 0). Re-apply freq after slope so host/JSFX cannot reset it.
function Track.SetFilterSlope24(track, fx_idx, is_24)
    if not track or fx_idx == nil or fx_idx < 0 then return end
    local norm = r.TrackFX_GetParam(track, fx_idx, 0)
    if norm == nil then norm = 0.5 end
    norm = math.max(0, math.min(1, norm))
    r.TrackFX_SetParam(track, fx_idx, 1, is_24 and 1 or 0)
    r.TrackFX_SetParam(track, fx_idx, 0, norm)
end

-- norm 0 -> 20 Hz, 0.5 -> 1 kHz, 1 -> fmax (log scale with 1 kHz at middle)
function Track.NormToFreq(norm)
    if norm == nil then return 20 end
    norm = math.max(0, math.min(1, norm))
    local sr = r.GetSetProjectInfo(0, "PROJECT_SRATE", 0, false) or 44100
    local fmax = math.min(sr * 0.499, 20000)
    if norm <= 0.5 then
        return 20 * (50 ^ (2 * norm))
    else
        return 1000 * ((fmax / 1000) ^ (2 * (norm - 0.5)))
    end
end

function Track.FreqToNorm(freq)
    if freq == nil then return 0 end
    local sr = r.GetSetProjectInfo(0, "PROJECT_SRATE", 0, false) or 44100
    local fmax = math.min(sr * 0.499, 20000)
    freq = math.max(20, math.min(fmax, freq))
    if freq <= 1000 then
        return 0.5 * math.log(freq / 20) / math.log(50)
    else
        return 0.5 + 0.5 * math.log(freq / 1000) / math.log(fmax / 1000)
    end
end

function Track.GetMidiTransposeValue(track)
    local fx_idx = Track.FindMidiTransposeFX(track)
    if fx_idx == nil then return nil end
    local p_idx = find_transpose_param(track, fx_idx)
    if p_idx == nil then return nil end
    local val = r.TrackFX_GetParam(track, fx_idx, p_idx)
    return val
end


function Track.TransposeMidiFX(tracks, semitone_delta)
    if not tracks or #tracks == 0 then return end
    Utils.with_undo(semitone_delta > 0 and "Transpose MIDI +1 st" or "Transpose MIDI -1 st", function()
        for _, tr in ipairs(tracks) do
            if tr and r.ValidatePtr(tr, "MediaTrack*") then
                local fx_idx = ensure_mt_front(tr)
                if fx_idx ~= nil then
                    local p_idx = find_transpose_param(tr, fx_idx)
                    if p_idx ~= nil then
                        local val, minv, maxv = r.TrackFX_GetParam(tr, fx_idx, p_idx)
                        if val ~= nil and minv ~= nil and maxv ~= nil then
                            local new_val = val + semitone_delta
                            if new_val < minv then new_val = minv end
                            if new_val > maxv then new_val = maxv end
                            r.TrackFX_SetParam(tr, fx_idx, p_idx, new_val)
                            pcall(r.TrackFX_SetOpen, tr, fx_idx, false)
                        end
                    end
                end
            end
        end
    end)
end

function Track.SetMidiTransposeAbsolute(tracks, target)
    if not tracks or #tracks == 0 then return end
    Utils.with_undo("Set MIDI Transpose", function()
        for _, tr in ipairs(tracks) do
            if tr and r.ValidatePtr(tr, "MediaTrack*") then
                local fx_idx = ensure_mt_front(tr)
                if fx_idx ~= nil then
                    local p_idx = find_transpose_param(tr, fx_idx)
                    if p_idx ~= nil then
                        local _, minv, maxv = r.TrackFX_GetParam(tr, fx_idx, p_idx)
                        local new_val = target
                        if minv ~= nil and maxv ~= nil then
                            if new_val < minv then new_val = minv end
                            if new_val > maxv then new_val = maxv end
                        end
                        r.TrackFX_SetParam(tr, fx_idx, p_idx, new_val)
                        pcall(r.TrackFX_SetOpen, tr, fx_idx, false)
                    end
                end
            end
        end
    end)
end

function Track.UpdateMidiTransposeImmediate(tracks, target)
    if not tracks or #tracks == 0 then return end
    for _, tr in ipairs(tracks) do
        if tr and r.ValidatePtr(tr, "MediaTrack*") then
            local fx_idx = ensure_mt_front(tr)
            if fx_idx ~= nil then
                local p_idx = find_transpose_param(tr, fx_idx)
                if p_idx ~= nil then
                    local _, minv, maxv = r.TrackFX_GetParam(tr, fx_idx, p_idx)
                    local new_val = target
                    if minv ~= nil and maxv ~= nil then
                        if new_val < minv then new_val = minv end
                        if new_val > maxv then new_val = maxv end
                    end
                    r.TrackFX_SetParam(tr, fx_idx, p_idx, new_val)
                    pcall(r.TrackFX_SetOpen, tr, fx_idx, false)
                end
            end
        end
    end
end

function Track.FinalizeMidiTranspose()
    Utils.with_undo("Transpose MIDI", function() end)
end

function Track.ResetMidiTranspose(tracks)
    Track.RemoveMidiTransposeFX(tracks)
end

function Track.RemoveMidiTransposeFX(tracks)
    if not tracks or #tracks == 0 then return end
    Utils.with_undo("Remove MIDI Transpose", function()
        for _, tr in ipairs(tracks) do
            if tr and r.ValidatePtr(tr, "MediaTrack*") then
                local fx_idx = Track.FindMidiTransposeFX(tr)
                if fx_idx ~= nil then
                    pcall(r.TrackFX_Delete, tr, fx_idx)
                end
            end
        end
    end)
end

return Track
